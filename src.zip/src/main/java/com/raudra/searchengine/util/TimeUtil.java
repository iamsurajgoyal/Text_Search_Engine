package com.raudra.searchengine.util;

/**
 * Created by satheeesh on 22/11/16.
 */
public class TimeUtil {

    public static long getCurrentTimeInMs() {
        return System.currentTimeMillis();
    }
}
