package com.raudra.searchengine.config;

/**
 * Created by satheeesh on 22/11/16.
 */
public class StopWordsConfig {
    public static final String STOP_WORD_FILE = "/home/toothless/Desktop/SearchEngine/src/main/resources/stopwords.txt";
    public static final String STOP_WORD_DELIMITER=",";
}
