package ArrayFinalAssignment;
import java.util.Scanner;
public class ArrayIntersection {
	
	public static void intersection(int input1[], int input2[]) {
		for(int i =0;i<input1.length;i++) {
			for(int j =0;j<input2.length;j++) {
				if(input1[i] == input2[j]) {
					System.out.println(input1[i]);
				}
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int m = sc.nextInt();
		
		int arr1[] = new int[n];
		int arr2[] = new int[m];
		
		for(int i = 0;i<n;i++) {
			arr1[i] = sc.nextInt();
		}
		for(int j = 0;j<n;j++) {
			arr2[j] = sc.nextInt();
		}
		
		intersection(arr1, arr2);
		

	}

}
