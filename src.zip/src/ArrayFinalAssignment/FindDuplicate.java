package ArrayFinalAssignment;
import java.util.Scanner;
public class FindDuplicate {
	
	public static int Duplicate(int arr[],int n) {
		for(int i=1;i<=n;i++) {
			for(int j=1;j<=n;j++) {
				if(i != j && arr[i] == arr[j]);
				return arr[i];
			}
		}
		return Integer.MAX_VALUE;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int arr[] = {0 ,7 ,2 ,5 ,4 ,7 ,1 ,3 ,6}; 
		int n = arr.length; 
        System.out.println("Element occurring twice is " + 
                            Duplicate(arr,n) );
		
//		int n = sc.nextInt();
//		
//		int a = Duplicate(arr, n);

	}

}
