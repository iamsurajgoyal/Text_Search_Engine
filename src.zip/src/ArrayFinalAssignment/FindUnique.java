package ArrayFinalAssignment;

public class FindUnique {
	
	public static int UniqueN(int arr[], int n) {
		int res = arr[0];
		for(int i = 1;i<n;i++) {
			res = res ^ arr[i];
		}
		return res;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {3, 2, 5, 4, 5, 3, 4}; 
		int n = arr.length; 
        System.out.println("Element occurring once is " + 
                            UniqueN(arr,n) );

	}

}
